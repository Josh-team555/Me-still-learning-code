import java.util.Scanner;
import java.lang.Math;
public class Calculator {
    private static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
        double answer = 0;
        boolean finished = false;
        double[] numbers = new double[2];
        String operation;
        System.out.println("Welcome to the Calculator! You can use Addition, Subtraction, Multiplication, Division, Squaring, and Square roots!");
        System.out.println("Import a number to begin!");
        numbers[0] = input.nextDouble();
        while (!finished) {
            System.out.println("Import an operation");
            operation = input.next();
            if (operation.equals("addition") || operation.equals("Addition") || operation.equals("+")) {
                operation = "+";
            } else if (operation.equals("subtraction") || operation.equals("Subtraction") || operation.equals("-")) {
                operation = "-";
            } else if (operation.equals("multiplication") || operation.equals("Multiplication") || operation.equals("*")) {
                operation = "*";
            } else if (operation.equals("division") || operation.equals("Division") || operation.equals("/")) {
                operation = "/";
            } else if (operation.equals("^2") || operation.equals("square") || operation.equals("Square") || operation.equals("Squared") || operation.equals("squared")) {
                operation = "^";
            } else if (operation.equals("sqrt") || operation.equals("Sqrt")) {
                operation = "square root";
            } else if (operation.equals("off") || operation.equals("Off")){
                return;
            } else {
                System.out.println("invalid input please try again");
                return;
            }

            System.out.println(numbers[0] + " " + operation);
            if  (operation.equals("^") || operation.equals("square root")) {
                System.out.println(numbers[0] + " " + operation + " = ");
            } else {
                System.out.println("Import a second number");
                numbers[1] = input.nextDouble();
                System.out.print(numbers[0] + " " + operation + " " + numbers[1] + " = ");
            }
            if (operation.equals("+")) {
                answer = numbers[0] + numbers[1];
            } else if (operation.equals("-")) {
                answer = numbers[0] - numbers[1];
            } else if (operation.equals("*")) {
                answer = numbers[0] * numbers[1];
            } else if (operation.equals("/")) {
                answer = numbers[0] / numbers[1];
            } else if (operation.equals("^")) {
                answer = numbers[0] * numbers[0];
            } else if (operation.equals("square root")) {
                answer = Math.sqrt(numbers[0]);
            }
            System.out.println(answer);
            numbers[0] = answer;
            System.out.println("Clear?(Y/N)");
            if (input.next().equals("Y") || input.next().equals("y")) {
                System.out.println("Import First Number");
                numbers[0] = input.nextDouble();
            }
        }
    }
}
