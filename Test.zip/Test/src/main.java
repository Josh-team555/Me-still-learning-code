import java.util.Scanner;
import java.lang.Math;
public class main {
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Enter x1: ");
        double x1 = input.nextDouble();
        System.out.println("Enter x2: ");
        double x2 = input.nextDouble();
        System.out.println("Enter y1: ");
        double y1 = input.nextDouble();
        System.out.println("Enter y2: ");
        double y2 = input.nextDouble();
        double distance = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        System.out.println("Distance between point = ");
        System.out.println(distance);
    }
}