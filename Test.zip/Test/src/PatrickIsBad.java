import java.util.Scanner;

public class PatrickIsBad {
    public static double[] array;
    private static Scanner input = new Scanner(System.in);

public static void main(String[] args) {
    double averagevalue = 0;
        System.out.println("How many numbers are you averaging?");
        int numberofvalues = input.nextInt();
        array = new double[numberofvalues];
        for (int i = 0; i < numberofvalues; i++) {
            System.out.println("Enter number " +(i + 1) + " of " +numberofvalues);
            array[i] = input.nextDouble();
        }
        for (int i = 0; i < array.length; i++) {
          averagevalue = averagevalue + array[i];
        }
        averagevalue = averagevalue/numberofvalues;
        System.out.println(averagevalue);
}
    }