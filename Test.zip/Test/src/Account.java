import java.util.Scanner;

class Account {
    private static int[] moneyPerAccount = new int[5];
    static Scanner input = new Scanner(System.in);
    static String latestIn;
    static String[] passwords = new String[5];
    static String[] usernames = new String[5];
    private static int activeAccount = 0;
    static boolean access = true;
    static boolean usingAccount = false;

    Account() {
        System.out.println("Enter your username(it must be 1 word): ");
        latestIn = input.next();
        if (latestIn.equals("Patrick") || latestIn.equals("patrick") || latestIn.equals("Harry") || latestIn.equals("harry") || latestIn.equals("Harrison") || latestIn.equals("harrison") || latestIn.equals("Mr_Gideon")) {
            System.out.println("Thank you for teaching me how to code in java. I really appreciate it. ");
        }
        String name = latestIn;
        System.out.println("Enter your password(it must be 1 word): ");
        latestIn = input.next();
        String password = latestIn;
        System.out.println("How much money do you want to start with?");
        int startCash = input.nextInt();
            if (usernames[0].equals("ready") && passwords[0].equals("ready")) {
                usernames[0] = name;
                passwords[0] = password;
                moneyPerAccount[0] = startCash;
                System.out.println("You can use: deposit, withdraw, checkBalance, and delete");
                System.out.println("Ok! You're all good! Bye");
            } else if (usernames[1].equals("ready") && passwords[1].equals("ready")) {
                usernames[1] = name;
                passwords[1] = password;
                moneyPerAccount[1] = startCash;
                System.out.println("You can use: deposit, withdraw, checkBalance, and delete");
                System.out.println("Ok! You're all good! Bye");
            } else if (usernames[2].equals("ready") && passwords[2].equals("ready")) {
                usernames[2] = name;
                passwords[2] = password;
                moneyPerAccount[2] = startCash;
                System.out.println("You can use: deposit, withdraw, checkBalance, and delete");
                System.out.println("Ok! You're all good! Bye");
            } else if (usernames[3].equals("ready") && passwords[3].equals("ready")) {
                usernames[3] = name;
                passwords[3] = password;
                moneyPerAccount[3] = startCash;
                System.out.println("You can use: deposit, withdraw, checkBalance, and delete");
                System.out.println("Ok! You're all good! Bye");
            } else if (usernames[4].equals("ready") && passwords[4].equals("ready")) {
                usernames[4] = name;
                passwords[4] = password;
                moneyPerAccount[4] = startCash;
                System.out.println("You can use: deposit, withdraw, checkBalance, and delete");
                System.out.println("Ok! You're all good! Bye");
            } else {
                System.out.println("No space left. Ask someone to delete an account");
            }


    }
    void Deposit() {
        int dorw;
        if (latestIn.equals("Deposit") || latestIn.equals("deposit")) {
            dorw = 1;
        } else {
            dorw = 2;
        }
        System.out.println("Enter your username: ");
        latestIn = input.next();
        if (!latestIn.equals("ready")) {
            if (usernames[0].equals(latestIn)) {
                activeAccount = 0;
            } else if (usernames[1].equals(latestIn)) {
                activeAccount = 1;
            } else if (usernames[2].equals(latestIn)) {
                activeAccount = 2;
            } else if (usernames[3].equals(latestIn)) {
                activeAccount = 3;
            } else if (usernames[4].equals(latestIn)) {
                activeAccount = 4;
            } else {
                System.out.println("That is not a valid username. Try createAccount");
                access = false;
            }
            if (access) {
                System.out.println("Enter your password: ");
                latestIn = input.next();
                if (passwords[activeAccount].equals(latestIn)) {
                    if (dorw == 1) {
                        System.out.println("How much would you like to deposit?");
                        moneyPerAccount[activeAccount] = input.nextInt() + moneyPerAccount[activeAccount];
                    } else {
                        System.out.println("How much would you like to withdraw?");
                        moneyPerAccount[activeAccount] = moneyPerAccount[activeAccount] - input.nextInt();
                    }

                    System.out.println("You now have $" + moneyPerAccount[activeAccount]);
                } else {
                    System.out.println("Wrong password. Try createAccount");
                    access = false;
                }
            }
        } else {
            System.out.println("Invalid username");
            access = false;
        }
    }
    void Delete() {
        System.out.println("Are you sure?(Y/N)");
        latestIn = input.next();
        if (latestIn.equals("Y") || latestIn.equals("y") || latestIn.equals("Yes") || latestIn.equals("yes")) {
            System.out.println("Enter your username: ");
            latestIn = input.next();
            if (!latestIn.equals("ready")) {
                if (usernames[0].equals(latestIn)) {
                    activeAccount = 0;
                } else if (usernames[1].equals(latestIn)) {
                    activeAccount = 1;
                } else if (usernames[2].equals(latestIn)) {
                    activeAccount = 2;
                } else if (usernames[3].equals(latestIn)) {
                    activeAccount = 3;
                } else if (usernames[4].equals(latestIn)) {
                    activeAccount = 4;
                } else {
                    System.out.println("That is not a valid username. Try createAccount");
                    access = false;
                }
                if (access) {
                    System.out.println("Enter your password: ");
                    latestIn = input.next();
                    if (passwords[activeAccount].equals(latestIn)) {
                        passwords[activeAccount] = "ready";
                        usernames[activeAccount] = "ready";
                        moneyPerAccount[activeAccount] = 0;
                        System.out.println("Done. Account deleted.");
                    } else {
                        System.out.println("Wrong password. Try createAccount");
                        access = false;
                    }
                }
            } else {
                System.out.println("Invalid username");
                access = false;
            }
        }
    }
    void checkBalance() {
        System.out.println("Enter your username: ");
        latestIn = input.next();
        if (!latestIn.equals("ready")) {
            if (usernames[0].equals(latestIn)) {
                activeAccount = 0;
            } else if (usernames[1].equals(latestIn)) {
                activeAccount = 1;
            } else if (usernames[2].equals(latestIn)) {
                activeAccount = 2;
            } else if (usernames[3].equals(latestIn)) {
                activeAccount = 3;
            } else if (usernames[4].equals(latestIn)) {
                activeAccount = 4;
            } else {
                System.out.println("That is not a valid username. Try createAccount");
                access = false;
            }
            if (access) {
                System.out.println("Enter your password: ");
                latestIn = input.next();
                if (passwords[activeAccount].equals(latestIn)) {
                    System.out.println("You have $" + moneyPerAccount[activeAccount]);
                } else {
                    System.out.println("Wrong password. Try createAccount");
                    access = false;
                }
            }
        } else {
            System.out.println("Invalid username");
            access = false;
        }
    }
}

