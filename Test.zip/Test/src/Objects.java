public class Objects {
    public static void main(String[] args) {
        Person p = new Person.Codling("Patrick", 200, 555, 2);
        p.Talk();
        Person h = new Person.Buildling("Harry", 14, 555, "the plasma cutter");
        h.Talk();
    }
}