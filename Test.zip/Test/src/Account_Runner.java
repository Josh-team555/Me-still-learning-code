public class Account_Runner {
    public static void main(String[] args) {
        Account.passwords[0] = "ready";
        Account.passwords[1] = "ready";
        Account.passwords[2] = "ready";
        Account.passwords[3] = "ready";
        Account.passwords[4] = "ready";
        Account.usernames[0] = "ready";
        Account.usernames[1] = "ready";
        Account.usernames[2] = "ready";
        Account.usernames[3] = "ready";
        Account.usernames[4] = "ready";
        System.out.println("Type createAccount to begin. ");
        Account.latestIn = Account.input.next();
        while (Account.access) {
            if (Account.latestIn.equals("createAccount")) {
                    Account a = new Account();
                    Account.latestIn = Account.input.next();
                    Account.usingAccount = true;
                    while(Account.usingAccount) {
                        if (Account.latestIn.equals("Deposit") || Account.latestIn.equals("deposit") || Account.latestIn.equals("Withdraw") || Account.latestIn.equals("withdraw")) {
                            a.Deposit();
                            Account.latestIn = Account.input.next();
                        } else if (Account.latestIn.equals("Delete") || Account.latestIn.equals("delete")) {
                            a.Delete();
                            Account.latestIn = Account.input.next();
                        } else if (Account.latestIn.equals("checkBalance") || Account.latestIn.equals("CheckBalance") || Account.latestIn.equals("checkbalance") || Account.latestIn.equals("Checkbalance")) {
                            a.checkBalance();
                            Account.latestIn = Account.input.next();
                        }
                        if (Account.latestIn.equals("createAccount")) {
                            Account.usingAccount = false;
                        }
                        Account.access = true;
                    }
            }
        }
    }
}