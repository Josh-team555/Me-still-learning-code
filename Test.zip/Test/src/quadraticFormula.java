import java.lang.Math;
class quadraticFormula {
     quadraticFormula(double a, double b, double c) {
        quadratic_runner.x1 = ((-1 * b) + Math.sqrt((b * b) + (-4 * a * c))) / (2 * a);
        quadratic_runner.x2 = ((-1 * b) - Math.sqrt((b * b) + (-4 * a * c))) / (2 * a);

    }
}
