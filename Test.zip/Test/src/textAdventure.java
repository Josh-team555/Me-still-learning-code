import java.util.Scanner;
import java.util.Random;
public class textAdventure {
    private static Scanner input = new Scanner(System.in);
    private static String[] Inventory = new String[10];

    public static void main(String[] args) {
        System.out.println("Welcome to this Text Adventure Game!");
        System.out.println("Rate how you feel 1-10:");
        int howPlayerFeels = input.nextInt();
        double placeInGame = 0;
        boolean attack = false;
        String[] Enemies = new String[5];
        int[] enemiesHealth = new int[5];
        int playerHealth = 100;
        int attackMode;
        boolean poisoned = false;
        Random rand = new Random();
        String latestAnswer;

        Inventory[0] = "1 Water";
        Inventory[1] = "1 Impossible Burger";
        Inventory[2] = "1 Mystery Meat";
        Inventory[3] = "1 Wooden Sword(8 damage)";
        Inventory[4] = "1 Wooden Shield(blocks 5 damage)";
        Inventory[5] = "2 Leather Boots";
        if (howPlayerFeels > 5) {
            System.out.println("That's great! Now let's play!");
        } else if (howPlayerFeels < 5) {
            System.out.println("I hope you feel better");
        } else {
            System.out.println("That is okay I hope you enjoy this game:");
        }
        System.out.println("Who are you?(You can put any name)");
        String character = input.next();
        System.out.println(character + " Welcome to the ...");
        System.out.println("____                               |  ");
        System.out.println("|   |  ____   _____   ____  ___  --|--");
        System.out.println("|   | |____|  |____  |____| |      |  ");
        System.out.println("|___| |____    ____| |___   |      |  ");
        System.out.println("Ready to continue?(Y/N)");
        if (input.next().equals("N")) {
            return;
        }


        System.out.println("You have: ");
        for (String s : Inventory) {
            System.out.println(s);
        }
        System.out.println("Maximum amount of items you can have is 10");
        System.out.println("You see smoke in the sky. Do you want to walk towards it?(Y/N)");
        latestAnswer = input.next();
        if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
            placeInGame = 1;
        } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
            placeInGame = 2;
        }
        if (placeInGame == 1) {
            System.out.println("You walk for a day. The sun sets. Do you want to continue or rest and continue in the morning?");
            latestAnswer = input.next();
            if (latestAnswer.equals("continue") || latestAnswer.equals("Continue")) {
                placeInGame = 1.1;
            } else {
                placeInGame = 1.2;
            }
        }
        if (placeInGame == 2) {
            System.out.println("You see the ocean. Do you want to walk towards it?(Y/N)");
            latestAnswer = input.next();
            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                placeInGame = 2.1;
            } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                placeInGame = 3.1;
            }
        }
        if (placeInGame == 1.1) {
            System.out.println("Oh-No! You stumble wearily upon a group of Trolls training for war with the frightening unicorns");
            Enemies[0] = "Troll";
            Enemies[1] = "Troll";
            Enemies[2] = "Troll";
            enemiesHealth[0] = 15;
            enemiesHealth[1] = 15;
            enemiesHealth[2] = 15;
            attack = true;

            while (attack) {
                for (int i = 0; i < 3; i++) {
                    System.out.println(Enemies[i] + (i + 1) + " has " + enemiesHealth[i] + " health.");
                }
                System.out.println("You have " + playerHealth + " health.");
                System.out.println("Do you want to attack or defend?(A/D)");
                latestAnswer = input.next();
                if (latestAnswer.equals("A") || latestAnswer.equals("a")) {
                    attackMode = 1;
                    if (enemiesHealth[0] > 0) {
                        enemiesHealth[0] = enemiesHealth[0] - 8;
                    } else if (enemiesHealth[1] > 0) {
                        enemiesHealth[1] = enemiesHealth[1] - 8;
                    } else if (enemiesHealth[2] > 0) {
                        enemiesHealth[2] = enemiesHealth[2] - 8;
                    }
                } else {
                    attackMode = 2;
                }
                System.out.println("The Trolls attack!!!");
                if (enemiesHealth[0] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 5;
                    } else {
                        playerHealth = playerHealth - (rand.nextInt(5) + 3);
                    }
                } else {
                    System.out.println("You killed Troll1");
                }
                if (enemiesHealth[1] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 5;
                    } else {
                        playerHealth = playerHealth - (rand.nextInt(5) + 3);
                    }
                } else {
                    System.out.println("You killed Troll2");
                }
                if (enemiesHealth[2] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 5;

                    } else {
                        playerHealth = playerHealth - (rand.nextInt(5) + 3);
                    }
                } else {
                    System.out.println("You killed Troll3");
                }

                if (playerHealth <= 0) {
                    System.out.println("Sorry you died.");
                    return;
                }
                if (enemiesHealth[0] <= 0 && enemiesHealth[1] <= 0 && enemiesHealth[2] <= 0) {
                    attack = false;
                    placeInGame = 1.11;
                    System.out.println("You win the fight!");
                    System.out.println("The goblins had:");
                    System.out.println("5 gold coins");
                    System.out.println("1 Iron Sword(10 damage)");
                    System.out.println("1 Small Healing Potion");
                    System.out.println("Do you want these items?(Y/N)");
                    latestAnswer = input.next();
                    if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                        Inventory[3] = "1 Iron Sword(10 damage)";
                        Inventory[6] = "5 Gold Coins";
                        Inventory[8] = "1 Small Healing Potion";
                        System.out.println("You now have: ");
                        for (String s : Inventory) {
                            System.out.println(s);
                        }
                        System.out.println("Maximum amount of items you can have is 10");
                        System.out.println("You have " + playerHealth + " health");
                        System.out.println("Do you want to use your small healing potion?(Y/N)");
                        latestAnswer = input.next();
                        if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                            playerHealth = playerHealth + 35;
                            System.out.println("You now have " + playerHealth + " health");
                            Inventory[8] = "null";
                        }
                    }
                }
            }
        }
        if (placeInGame == 1.11) {
            System.out.println("You see a tall group of trees in the distance. Do you want to go towards them?(Y/N)");
            latestAnswer = input.next();
            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                placeInGame = 1.111;
            } else {
                System.out.println("You see 4 Goblins walking slowly over the sand. Do you want to attack them(A) or follow them(F)?");
                latestAnswer = input.next();
                if (latestAnswer.equals("A") || latestAnswer.equals("a")) {
                    placeInGame = 1.112;
                    attack = true;
                    Enemies[0] = "Goblin";
                    Enemies[1] = "Goblin";
                    Enemies[2] = "Goblin";
                    Enemies[3] = "Goblin";
                    enemiesHealth[0] = 18;
                    enemiesHealth[1] = 18;
                    enemiesHealth[2] = 18;
                    enemiesHealth[3] = 18;
                } else {
                    placeInGame = 1.113;
                }
            }
        }
        if (placeInGame == 1.112) {
            while(attack) {
                for (int i = 0; i < 4; i++) {
                    System.out.println(Enemies[i] + (i + 1) + " has " + enemiesHealth[i] + " health.");
                }
                System.out.println("You have " + playerHealth + " health.");
                System.out.println("Do you want to attack or defend?(A/D)");
                latestAnswer = input.next();
                if (latestAnswer.equals("A") || latestAnswer.equals("a")) {
                    attackMode = 1;
                    if (enemiesHealth[0] > 0) {
                        if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                            enemiesHealth[0] = enemiesHealth[0] - (rand.nextInt(4) + 10) ;
                        } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                            enemiesHealth[0] = enemiesHealth[0] - 8;
                        }
                    } else if (enemiesHealth[1] > 0) {
                        System.out.println("You killed Goblin1");
                        if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                            enemiesHealth[1] = enemiesHealth[1] - (rand.nextInt(4) + 10);
                        } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                            enemiesHealth[1] = enemiesHealth[1] - 8;
                        }
                    } else if (enemiesHealth[2] > 0) {
                        System.out.println("You killed Goblin2");
                        if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                            enemiesHealth[2] = enemiesHealth[2] - (rand.nextInt(4) + 10);
                        } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                            enemiesHealth[2] = enemiesHealth[2] - 8;
                        }
                    } else if (enemiesHealth[3] > 0) {
                        System.out.println("You killed Goblin3");
                        if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                            enemiesHealth[3] = enemiesHealth[3] - (rand.nextInt(4) + 10);
                        } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                            enemiesHealth[3] = enemiesHealth[3] - 8;
                        }

                    } else {
                        System.out.println("You killed Goblin4");
                        System.out.println("You win the fight!!");
                    }
                } else {
                    attackMode = 2;
                }
                if (enemiesHealth[0] > 0) {
                    System.out.println("The Goblins attack!");
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 3;
                    } else {
                        playerHealth = playerHealth - (rand.nextInt(4) + 4);
                    }
                }
                if (enemiesHealth[1] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 3;
                    } else {
                        playerHealth = playerHealth - (rand.nextInt(4) + 3);
                    }
                }
                if (enemiesHealth[2] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 3;
                    } else {
                        playerHealth = playerHealth - (rand.nextInt(4) + 3);
                    }
                }
                if (enemiesHealth[3] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 3;
                    } else {
                        playerHealth = playerHealth - (rand.nextInt(4) + 4);
                    }
                }

                if (playerHealth <= 0) {
                    System.out.println("Sorry you died.");
                    return;
                }
                if ((enemiesHealth[0] <= 0) && enemiesHealth[1] <= 0 && enemiesHealth[2] <= 0 && enemiesHealth[3] <= 0 && enemiesHealth[4] <= 0) {
                    attack = false;
                    placeInGame = 1.1121;
                    System.out.println("You win the fight!");
                    System.out.println("The Goblins had:");
                    System.out.println("50 Gold Coins");
                    System.out.println("2 Healing Potions");
                    System.out.println("1 Steel Sword");
                    System.out.println("Do you want these items?(Y/N)");
                    latestAnswer = input.next();
                    if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                        Inventory[3] = "1 Steel Sword(20 damage)";
                        Inventory[6] = "55 Gold Coins";
                        Inventory[8] = "2 Healing Potion";
                        System.out.println("You now have: ");
                        for (String s : Inventory) {
                            System.out.println(s);
                        }
                        System.out.println("Maximum amount of items you can have is 10");
                        System.out.println("You have " + playerHealth + " health");
                        System.out.println("Do you want to use a healing potion?(Y/N)");
                        latestAnswer = input.next();
                        if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                            playerHealth = playerHealth + 50;
                            System.out.println("You now have " + playerHealth + " health");
                            Inventory[8] = "null";
                        }
                    }
                }
            }
        }



        if (placeInGame == 1.113) {
            System.out.println("You follow the Goblins across the desert the rest of the day. Just as the sun sets they enter into a looming expanse of trees. Do you want to follow them?(Y/N)");
            latestAnswer = input.next();
            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                placeInGame = 1.1131;
            } else {
                placeInGame = 1.1132;
            }
        }
        if (placeInGame == 1.2) {
            System.out.println("You set up camp. Do you want to eat Mystery Meat(M), Impossible Burger(I), or nothing(N)");
            latestAnswer = input.next();
            switch (latestAnswer) {
                case "M":
                case "m":
                    if (rand.nextInt(10) == 9) {
                        System.out.println("You have Trichinellosis");
                        System.out.println("You die.");
                        return;
                    } else if (rand.nextInt(10) == 6) {
                        System.out.println("You heal completely!");
                        playerHealth = 100;
                    } else {
                        System.out.println("You have extreme strength until the sunrises. Do you want to continue onwards?(Y/N)");
                        latestAnswer = input.next();
                        if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                            placeInGame = 1.211;
                        } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                            placeInGame = 1.22;
                        }
                    }
                    break;
                case "I":
                case "i":
                    System.out.println("You helped not to kill the plant! Yay! You fall asleep until sunrise.");
                    placeInGame = 1.22;
                    break;
                case "N":
                case "n":
                    System.out.println("You fall asleep until sunrise");
                    placeInGame = 1.22;
                    break;
            }
        }
        if (placeInGame == 1.211) {
            System.out.println("Do you want to continue towards the smoke?(Y/N)");
            latestAnswer = input.next();
            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                System.out.println("You head towards the smoke. You climb a ridge and right below you is the Troll army. RUN!!!!");
                placeInGame = 1.2111;
            } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                placeInGame = 1.2112;
            }
        }
        if (placeInGame == 1.2111) {
            System.out.println("You continue running but Troll 'archers' are slingshoting you with small rocks. Suddenly your legs fly out from under you while climbing down the ridge. ");
            System.out.println("You find a cave to hide in and the Trolls don't find you. You fall asleep from your wounds and exhaustion. When you wake up a dwarf is staring at you.");
            System.out.println("'I don't know what possessed you to do that and I don't want to know. Come with me into the mines.' ");
            System.out.println("You follow him into the mountain and find a great expanse of railways, waterfalls and gold.");
            System.out.println("'Do you want to stay with us for a bit to get better? We'd pay you for working. (Y/N)");
            latestAnswer = input.next();
            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                placeInGame = 1.21111;
            } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                placeInGame = 1.21112;
            }
        }
        if (placeInGame == 1.21111) {
            System.out.println("Welcome to the ...");
            System.out.println("    __      __   |   __    ______");
            System.out.println("  |    |  |   |  |  |  |  |___");
            System.out.println(" |      ||     | |  |  |  |_____");
        }
            if (placeInGame == 1.22) {
                System.out.println("When you wake the smoke in the sky is gone.");
                System.out.println("Do you want to continue towards where the smoke was?(Y/N)");
                latestAnswer = input.next();
                if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                    placeInGame = 1.221;
                } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                    placeInGame = 1.222;
                }
            }
            if (placeInGame == 1.221) {
                System.out.println("You travel towards where the smoke was and find an empty campsite. Then, a group of Orcs start marching across the hills. They see you and attack!");
                placeInGame = 1.2211;
                attack = true;
                Enemies[0] = "Orc";
                Enemies[1] = "Orc";
                Enemies[2] = "Orc";
                enemiesHealth[0] = 10;
                enemiesHealth[1] = 10;
                enemiesHealth[2] = 10;
            }
            if (placeInGame == 1.222) {
                System.out.println("You begin walking aimlessly in search of a town. You don't see a hole and fall into Ye pit of Ye Sarlac.");
                return;
            }
            if (placeInGame == 1.2211) {
                while (attack) {
                    for (int i = 0; i < 3; i++) {
                        System.out.println(Enemies[i] + (i + 1) + " has " + enemiesHealth[i] + " health.");
                    }
                    System.out.println("You have " + playerHealth + " health.");
                    System.out.println("Do you want to attack or defend?(A/D)");
                    latestAnswer = input.next();
                    if (latestAnswer.equals("A") || latestAnswer.equals("a")) {
                        attackMode = 1;
                        if (enemiesHealth[0] > 0) {
                            if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                                enemiesHealth[0] = enemiesHealth[0] - (rand.nextInt(5) + 10);
                            } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                                enemiesHealth[0] = enemiesHealth[0] - 8;
                            }
                        } else if (enemiesHealth[1] > 0) {
                            System.out.println("You killed Orc1");
                            if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                                enemiesHealth[1] = enemiesHealth[1] - (rand.nextInt(5) + 10);
                            } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                                enemiesHealth[1] = enemiesHealth[1] - 8;
                            }
                        } else if (enemiesHealth[2] > 0){
                            System.out.println("You killed Orc2");
                            if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                                enemiesHealth[2] = enemiesHealth[2] - (rand.nextInt(5) + 10);
                            } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                                enemiesHealth[2] = enemiesHealth[2] - 8;
                            }
                        } else if (enemiesHealth[3] > 0) {
                            System.out.println("You killed Orc3");
                            System.out.println("You win the fight!");
                        }
                    } else {
                        attackMode = 2;
                    }
                    if (enemiesHealth[0] > 0) {
                        System.out.println("The Orcs attack!");
                        if (attackMode == 2) {
                            playerHealth = playerHealth - 6;
                        } else {
                            playerHealth = playerHealth - (rand.nextInt(5) + 6);
                        }
                    }
                    if (enemiesHealth[1] > 0) {
                        if (attackMode == 2) {
                            playerHealth = playerHealth - 6;
                        } else {
                            playerHealth = playerHealth - (rand.nextInt(5) + 6);
                        }
                    }
                    if (enemiesHealth[2] > 0) {
                        if (attackMode == 2) {
                            playerHealth = playerHealth - 6;
                        } else {
                            playerHealth = playerHealth - (rand.nextInt(5) + 6);
                        }
                    }
                    if (playerHealth <= 0) {
                        System.out.println("Sorry you died.");
                        return;
                    }
                    if (enemiesHealth[0] <= 0 && enemiesHealth[1] <= 0 && enemiesHealth[2] <= 0) {
                        attack = false;
                        placeInGame = 1.22111;
                        System.out.println("You win the fight!");
                        System.out.println("The Orcs had:");
                        System.out.println("25 Gold Coins");
                        System.out.println("1 Healing Potion");
                        System.out.println("1 Iron Sword(10 damage)");
                        System.out.println("Do you want these items?(Y/N)");
                        latestAnswer = input.next();
                        if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                            Inventory[3] = "1 Iron Sword(10 damage)";
                            Inventory[7] = "25 Gold Coins";
                            Inventory[8] = "1 Healing Potion";
                            System.out.println("You now have: ");
                            for (String s : Inventory) {
                                System.out.println(s);
                            }
                            System.out.println("Maximum amount of items you can have is 10");
                            System.out.println("You have " + playerHealth + " health");
                            System.out.println("Do you want to use your healing potion to heal 50 health?(Y/N)");
                            latestAnswer = input.next();
                            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                                playerHealth = playerHealth + 50;
                                System.out.println("You now have " + playerHealth + " health");
                                Inventory[8] = "null";
                            }
                        }
                    }
                }
            }
            if (placeInGame == 2.1) {
                System.out.println("Welcome to the ...");
                System.out.println(" _____                      |     ");
                System.out.println("|     |  ____   ___   ___   |____ ");
                System.out.println("|-----| |____| |___| |      |    |");
                System.out.println("|_____| |____  |   | |___   |    |");
                System.out.println("You see a group of crabs. Do you want to kill them and store their meat?(Y/N)");
                latestAnswer = input.next();
                if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                    Inventory[6] = "3 Crab Meat";
                    placeInGame = 2.11;
                } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                    System.out.println("The sun sets. You feel tired.");
                    placeInGame = 2.12;
                }
            }
            if (placeInGame == 2.11) {
                System.out.println("Do you want to walk along the beach?(Y/N)");
                latestAnswer = input.next();
                if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                    placeInGame = 2.111;
                } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                    placeInGame = 2.112;
                }
            }
            if (placeInGame == 2.112) {
                System.out.println("Some rocks join each other and become a carpet. This sweeps you up and carries you over the ocean.");
                System.out.println("Suddenly, it veers straight into the ocean and dives beneath the waves. You then realize you can breath. Welcome to the ...");
                System.out.println(" _____                    ______   |               ");
                System.out.println("|       ____   ____      |         |   ____    ____   ____");
                System.out.println("|----| |____| |____|     |----     |  |    |  |    | |");
                System.out.println("_____| |____  |    |     |         |  |____|  |____| |");
                System.out.print("Do you want to try to swim to the surface(S) or stay in place(P)?");
                latestAnswer = input.next();
                if (latestAnswer.equals("S") || latestAnswer.equals("s")) {
                    placeInGame = 2.1121;
                    System.out.println("You hear a voice say 'You won't get very far doing that'");
                } else if (latestAnswer.equals("P") || latestAnswer.equals("p")) {
                    placeInGame = 2.1121;
                }
            }
            if (placeInGame == 2.1121) {
                System.out.println("A man with a staff approach you. He says 'I am a practitioner of magic, you can be one too. Would you like to?'(Y/N)");
                latestAnswer = input.next();
                if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                    placeInGame = 2.11211;
                } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                    System.out.println("'Fine. Good luck getting back to the beach.' He walks away and suddenly you don't have any air. You try to swim to the surface but a shark eats you.");
                    System.out.println("Surprisingly aren't dead! JK you actually are. BYE!");
                    return;
                }
            }
            if (placeInGame == 2.11211) {
                System.out.println("'So, first you need a staff. Here you go!'");
                System.out.println("You now have a magicians staff!");
                Inventory[9] = "1 Magicians Staff";
                System.out.println("'Now you can hit enemies from farther away!'");
                System.out.println("'I am going to fight a dragon now, bye!'");
                System.out.println("Some sharks immediately attack you after he leaves.");
                placeInGame = 2.112111;
            }
            if (placeInGame == 2.12) {
                    System.out.println("You set up camp. Do you want to eat Mystery Meat(M), Impossible Burger(I), or nothing(N)");
                    latestAnswer = input.next();
                switch (latestAnswer) {
                    case "M":
                    case "m":
                        if (rand.nextInt(10) == 9) {
                            System.out.println("You have Trichinellosis");
                            System.out.println("You die.");
                            return;
                        } else if (rand.nextInt(10) == 6) {
                            System.out.println("You heal all of your health back");
                            playerHealth = 100;
                            placeInGame = 2.122;

                        } else {
                            System.out.println("You have extreme strength until the sunrises. Do you want to continue onwards?(Y/N)");
                            latestAnswer = input.next();
                            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                                placeInGame = 2.121;
                            } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                                placeInGame = 2.122;
                            }
                        }
                        break;
                    case "I":
                    case "i":
                        System.out.println("You helped not to kill the plant! Yay! You fall asleep until sunrise.");
                        placeInGame = 2.122;
                        break;
                    case "N":
                    case "n":
                        System.out.println("You fall asleep until sunrise");
                        placeInGame = 2.122;
                        break;
                }
            }
            if (placeInGame == 2.121) {
                System.out.println("You continue onwards and travel into a forest");
                placeInGame = 2.1111;
            }

            if (placeInGame == 2.122) {
                System.out.println("When you wake up you hear a dull thumping behind you.");
                System.out.println("You turn around and see an army of skeletons marching across the sands. The person controlling them is a man without a nose in a black cape ");
                System.out.println("Do you want to run(Y/N)?");
                latestAnswer = input.next();
                if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                    placeInGame = 2.1221;
                } else {
                    System.out.println("As the soldiers march on, the man suddenly looks at you. A snake suddenly jumps at you from behind! ");
                    placeInGame = 2.1222;
                    attack = true;
                    Enemies[0] = "Nagini(the snake from Harry Potter)";
                    enemiesHealth[0] = 20;
                }
            }
            if (placeInGame == 2.1222) {
                while (attack) {
                    for (int i = 0; i < 1; i++) {
                        System.out.println(Enemies[i] + " has " + enemiesHealth[i] + " health.");
                    }
                    System.out.println("You have " + playerHealth + " health.");
                    System.out.println("Do you want to attack or defend?(A/D)");
                    latestAnswer = input.next();
                    if (latestAnswer.equals("A") || latestAnswer.equals("a")) {
                        attackMode = 1;
                        if (enemiesHealth[0] > 0) {
                            enemiesHealth[0] = enemiesHealth[0] - 8;
                        }
                    } else {
                        attackMode = 2;
                    }
                    System.out.println("The Snake attacks!!!");
                    if (enemiesHealth[0] > 0) {
                        if (attackMode == 2) {
                            playerHealth = playerHealth - 5;
                        } else {
                            playerHealth = playerHealth - (rand.nextInt(10) + 10);
                            if (poisoned) {
                                playerHealth = playerHealth - (rand.nextInt(20));
                            }
                            if (rand.nextInt(10) == 1 && !poisoned) {
                                System.out.println("You've been poisoned!!");
                                poisoned = true;
                            }
                        }
                    } else {
                        System.out.println("You killed The Snake");
                    }

                    if (playerHealth <= 0) {
                        System.out.println("Sorry you died.");
                        return;
                    }
                    if (enemiesHealth[0] <= 0) {
                        attack = false;
                        placeInGame = 1.11;
                        System.out.println("You win the fight!");
                        System.out.println("The Snake had:");
                        System.out.println("1 Jar Of Venom");
                        System.out.println("1 Iron Sword(10 damage)");
                        System.out.println("1 Small Healing Potion");
                        System.out.println("Do you want these items?(Y/N)");
                        latestAnswer = input.next();
                        if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                            Inventory[3] = "1 Iron Sword(10 damage)";
                            Inventory[9] = "1 Jar Of Venom";
                            Inventory[8] = "1 Small Healing Potion";
                            System.out.println("You now have: ");
                            for (String s : Inventory) {
                                System.out.println(s);
                            }
                            System.out.println("Maximum amount of items you can have is 10");
                            System.out.println("You have " + playerHealth + " health");
                            System.out.println("Do you want to use your small healing potion?(Y/N)");
                            latestAnswer = input.next();
                            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                                poisoned = false;
                                playerHealth = playerHealth + 35;
                                System.out.println("You now have " + playerHealth + " health");
                                Inventory[8] = "null";
                            }
                            placeInGame = 2.12221;
                        }
                    }
                }
            }
            if (placeInGame == 2.1221) {
                System.out.println("As you start to run, a snake bites you and then eats you. ");
                System.out.println("Guess What? You're dead!!");
                return;
            }
            if (placeInGame == 2.111) {
                System.out.println("You walk for 45 minutes along the beach. You see a forest looming in the distance. Do you want to go towards it?(Y/N)");
                latestAnswer = input.next();
                if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                    placeInGame = 2.1111;
                } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                    placeInGame = 2.1112;
                }
            }
            if (placeInGame == 2.1111) {
                System.out.println("Welcome to the ...");
                System.out.println(" ______                                 |");
                System.out.println("|        ____    ____    ____   ____  --|--");
                System.out.println("|---    |    |  |       |____| |____    |");
                System.out.println("|       |____|  |       |____   ____|   |");
                System.out.println("You start walking among the dense trees and then suddenly get thrown into the air by a net.");
                System.out.println("You have been captured by the elves. You bang your head on a tree branch and fall asleep");
                System.out.println("When you wake up you are not in the net. You are in a bed. Do you want to try to escape?(Y/N)");
                latestAnswer = input.next();
                if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                    placeInGame = 2.11111;
                } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                    placeInGame = 2.11112;
                }
            }
            if (placeInGame == 2.11111) {
                System.out.print("You run outside your room and it seems as though you are inside a palace. ");
                System.out.println("You find the nearest window and jump out landing on the forest floor. ");
                System.out.print("You start to run through the forest and immediately get lost. You then are suddenly surrounded by bright lights, fairies!");
                System.out.println(" Suddenly, all at once the fairies start to zap you!!");
                Enemies[0] = "Fairy";
                Enemies[1] = "Fairy";
                Enemies[2] = "Fairy";
                Enemies[3] = "Fairy";
                Enemies[4] = "Fairy";
                enemiesHealth[0] = 8;
                enemiesHealth[1] = 8;
                enemiesHealth[2] = 8;
                enemiesHealth[3] = 8;
                enemiesHealth[4] = 8;
                attack = true;
            }
        if (placeInGame == 2.11111) {
            while (attack) {
                for (int i = 0; i < 5; i++) {
                    System.out.println(Enemies[i] + (i + 1) + " has " + enemiesHealth[i] + " health.");
                }
                System.out.println("You have " + playerHealth + " health.");
                System.out.println("Do you want to attack or defend?(A/D)");
                latestAnswer = input.next();
                if (latestAnswer.equals("A") || latestAnswer.equals("a")) {
                    attackMode = 1;
                    if (enemiesHealth[0] > 0) {
                        if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                            enemiesHealth[0] = enemiesHealth[0] - (rand.nextInt(5) + 10);
                        } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                            enemiesHealth[0] = enemiesHealth[0] - 8;
                        }
                    } else if (enemiesHealth[1] > 0) {
                        System.out.println("You killed Fairy1");
                        if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                            enemiesHealth[1] = enemiesHealth[1] - (rand.nextInt(5) + 10);
                        } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                            enemiesHealth[1] = enemiesHealth[1] - 8;
                        }
                    } else if (enemiesHealth[2] > 0){
                        System.out.println("You killed Fairy2");
                        if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                            enemiesHealth[2] = enemiesHealth[2] - (rand.nextInt(5) + 10);
                        } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                            enemiesHealth[2] = enemiesHealth[2] - 8;
                        }
                    } else if (enemiesHealth[3] > 0) {
                        System.out.println("You killed Fairy3");
                        if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                            enemiesHealth[3] = enemiesHealth[3] - (rand.nextInt(5) + 10);
                        } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                            enemiesHealth[3] = enemiesHealth[3] - 8;
                        }
                    } else if (enemiesHealth[4] > 0) {
                        System.out.println("You killed Fairy4");
                        if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                            enemiesHealth[4] = enemiesHealth[4] - (rand.nextInt(5) + 10);
                        } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                            enemiesHealth[4] = enemiesHealth[4] - 8;
                        }
                    } else {
                        System.out.println("You killed Fairy5. ");
                        System.out.println("You win the fight!");
                    }
                } else {
                    attackMode = 2;
                }
                if (enemiesHealth[0] > 0) {
                    System.out.println("The Fairies attack!");
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 10;

                    } else {
                        playerHealth = playerHealth - (rand.nextInt(2) + 3);
                    }
                }
                if (enemiesHealth[1] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 10;

                    } else {
                        playerHealth = playerHealth - (rand.nextInt(2) + 3);
                    }
                }
                if (enemiesHealth[2] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 10;

                    } else {
                        playerHealth = playerHealth - (rand.nextInt(2) + 3);
                    }
                }
                if (enemiesHealth[3] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 10;

                    } else {
                        playerHealth = playerHealth - (rand.nextInt(2) + 3);
                    }
                }
                if (enemiesHealth[4] > 0) {
                    if (attackMode == 2) {
                        playerHealth = playerHealth - 10;

                    } else {
                        playerHealth = playerHealth - (rand.nextInt(2) + 3);
                    }
                }


                if (playerHealth <= 0) {
                    System.out.println("Sorry you died.");
                    return;
                }
                if (enemiesHealth[0] <= 0 && enemiesHealth[1] <= 0 && enemiesHealth[2] <= 0 && enemiesHealth[3] <= 0 && enemiesHealth[4] <= 0) {
                    attack = false;
                    placeInGame = 2.111111;
                    System.out.println("You win the fight!");
                    System.out.println("The Fairies had:");
                    System.out.println("15 Gold Coins");
                    System.out.println("1 Healing Potion");
                    System.out.println("1 Iron Sword(10 damage)");
                    System.out.println("Do you want these items?(Y/N)");
                    latestAnswer = input.next();
                    if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                        Inventory[3] = "1 Iron Sword(10 damage)";
                        Inventory[7] = "15 Gold Coins";
                        Inventory[8] = "1 Healing Potion";
                        System.out.println("You now have: ");
                        for (String s : Inventory) {
                            System.out.println(s);
                        }
                        System.out.println("Maximum amount of items you can have is 10");
                        System.out.println("You have " + playerHealth + " health");
                        System.out.println("Do you want to use your healing potion to heal 50 health?(Y/N)");
                        latestAnswer = input.next();
                        if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                            playerHealth = playerHealth + 50;
                            System.out.println("You now have " + playerHealth + " health");
                            Inventory[8] = "null";
                        }
                    }
                }
            }
        }
            if (placeInGame == 3.1) {
                System.out.println("You hear a loud grunt behind you. It's a unicorn!");
                System.out.println("Do you want to fight the unicorn or pet the unicorn?(F/P)");
                latestAnswer = input.next();
                if (latestAnswer.equals("P") || latestAnswer.equals("p")) {
                    System.out.println("You reach to pet the unicorn and it bites off your hand. The unicorn then charges at you and impales you. ");
                    System.out.println("You died. ");
                    return;
                } else if (latestAnswer.equals("F") || latestAnswer.equals("f")) {
                    placeInGame = 3.11;
                    Enemies[0] = "Unicorn";
                    enemiesHealth[0] = 30;
                    attack = true;
                }
            }
            if (placeInGame == 3.11) {
                while (attack) {
                    System.out.println("Unicorn has " + enemiesHealth[0] + " health");
                    System.out.println("You have " + playerHealth + " health.");
                    System.out.println("Do you want to attack or defend?(A/D)");
                    latestAnswer = input.next();
                    if (latestAnswer.equals("A") || latestAnswer.equals("a")) {
                        attackMode = 1;
                        if (enemiesHealth[0] > 0) {
                            enemiesHealth[0] = enemiesHealth[0] - 8;
                        }
                    } else {
                        attackMode = 2;
                    }
                    System.out.println("The Unicorn attacks!!!");
                    if (enemiesHealth[0] > 0) {
                        if (attackMode == 2) {
                            playerHealth = playerHealth - 7;

                        } else {
                            playerHealth = playerHealth - (rand.nextInt(10) + 13);
                        }
                    } else {
                        System.out.println("You killed by the Unicorn");
                    }

                    if (playerHealth <= 0) {
                        System.out.println("Sorry you died.");
                        return;
                    }
                    if ((enemiesHealth[0] <= 0)) {
                        attack = false;
                        placeInGame = 3.111;
                        System.out.println("You win the fight!");
                        System.out.println("The unicorn had:");
                        System.out.println("1 Jar of Sparkle Dust");
                        System.out.println("1 Iron Sword");
                        System.out.println("Do you want these items?(Y/N)");
                        latestAnswer = input.next();
                        if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                            Inventory[3] = "1 Iron Sword(10 damage)";
                            Inventory[6] = "1 Jar of Sparkle Dust";
                            System.out.println("You now have: ");
                            for (String s : Inventory) {
                                System.out.println(s);
                            }
                            System.out.println("Maximum amount of items you can have is 10");
                        }
                    }
                }
            }
            if (placeInGame == 3.111) {
                System.out.println("You have " + playerHealth + " health");
                System.out.println("The sky clouds over and begins to pour. ");
                System.out.println("You see a few stone buildings in the distance");
                System.out.println("Do you want to go towards them?(Y/N)");
                latestAnswer = input.next();
                if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                    placeInGame = 3.1111;
                } else if (latestAnswer.equals("N") || latestAnswer.equals("n")) {
                    placeInGame = 3.1112;
                }
            }
            if (placeInGame == 3.1112) {
                System.out.println("You are zapped by lightning and got killed!");
                return;
            }
            if (placeInGame == 3.1111) {
                System.out.println("Welcome to the ...");
                System.out.println(" _____  ___     |    |   |");
                System.out.println("|        |    --|--  |___|");
                System.out.println("|        |      |      |  ");
                System.out.println("|_____  _|_     |      |  ");
                System.out.println("You see some shady figures in an alley. Do you approach them?(Y/N)");
                latestAnswer = input.next();
                System.out.println("They jump out to attack you!");
                Enemies[0] = "?";
                Enemies[1] = "?";
                enemiesHealth[0] = 15;
                enemiesHealth[1] = 15;
                attack = true;
                placeInGame = 3.11111;
            }
            if (placeInGame == 3.11111) {
                while (attack) {
                    for (int i = 0; i < 2; i++) {
                        System.out.println(Enemies[i] + (i + 1) + " has " + enemiesHealth[i] + " health.");
                    }
                    System.out.println("You have " + playerHealth + " health.");
                    System.out.println("Do you want to attack or defend?(A/D)");
                    latestAnswer = input.next();
                    if (latestAnswer.equals("A") || latestAnswer.equals("a")) {
                        attackMode = 1;
                        if (enemiesHealth[0] > 0) {
                            if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                                enemiesHealth[0] = enemiesHealth[0] - (rand.nextInt(5) + 10);
                            } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                                enemiesHealth[0] = enemiesHealth[0] - 8;
                            }
                        } else if (enemiesHealth[1] > 0) {
                            System.out.println("You killed Figure1");
                            if (Inventory[3].equals("1 Iron Sword(10 damage)")) {
                                enemiesHealth[1] = enemiesHealth[1] - (rand.nextInt(5) + 10);
                            } else if (Inventory[3].equals("1 Wooden Sword(8 damage)")) {
                                enemiesHealth[1] = enemiesHealth[1] - 8;
                            }
                        } else {
                            System.out.println("You killed Figure2");
                            System.out.println("You win the fight!");
                        }
                    } else {
                        attackMode = 2;
                    }
                    if (enemiesHealth[0] > 0) {
                        System.out.println("The Figures attack!");
                        if (attackMode == 2) {
                            playerHealth = playerHealth - 10;

                        } else {
                            playerHealth = playerHealth - (rand.nextInt(10) + 9);
                        }
                    }
                    if (enemiesHealth[1] > 0) {
                        if (attackMode == 2) {
                            playerHealth = playerHealth - 10;

                        } else {
                            playerHealth = playerHealth - (rand.nextInt(10) + 9);
                        }
                    }


                    if (playerHealth <= 0) {
                        System.out.println("Sorry you died.");
                        return;
                    }
                    if ((enemiesHealth[0] <= 0 && attack) && enemiesHealth[1] <= 0) {
                        attack = false;
                        placeInGame = 3.111;
                        System.out.println("You win the fight!");
                        System.out.println("The Figures had:");
                        System.out.println("15 Gold Coins");
                        System.out.println("1 Healing Potion");
                        System.out.println("2 Dragon Hide Boots");
                        System.out.println("Do you want these items?(Y/N)");
                        latestAnswer = input.next();
                        if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                            Inventory[5] = "2 Dragon Hide Boots";
                            Inventory[7] = "15 Gold Coins";
                            Inventory[8] = "1 Healing Potion";
                            System.out.println("You now have: ");
                            for (String s : Inventory) {
                                System.out.println(s);
                            }
                            System.out.println("Maximum amount of items you can have is 10");
                            System.out.println("You have " + playerHealth + " health");
                            System.out.println("Do you want to use your healing potion to heal 50 health?(Y/N)");
                            latestAnswer = input.next();
                            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                                playerHealth = playerHealth + 50;
                                System.out.println("You now have " + playerHealth + " health");
                                Inventory[8] = "null";
                            }
                        }
                    }
                }
            }
            System.out.println("That's all for now bye " + character);
            System.out.println("Would you like to take a survey?(Y/N)");
            latestAnswer = input.next();
            if (latestAnswer.equals("Y") || latestAnswer.equals("y")) {
                System.out.println("Rate how you feel 1-10");
                if (input.nextInt() > 5) {
                    System.out.println("I'm glad you liked the game. Bye!");

                } else if (input.nextInt() < 5) {
                    System.out.println("Too bad you didn't like the game. Have a nice day " + character);
                }
            }



        }
    }