import java.lang.Math;
import java.util.Scanner;

public class RNG {
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int[] Numbers;
        double currentNumber = 0;
        System.out.println("How many numbers do you want the computer to find?");
        Numbers = new int[input.nextInt()];
        for (int i = 0; i < Numbers.length; i++) {
            System.out.println("Input number " + (i + 1) + " of " + Numbers.length);
            Numbers[i] = input.nextInt();
        }
        System.out.println("Ok finding numbers: ");
        for (int i = 0; i < Numbers.length; i ++) {
            while (currentNumber != Numbers[i]) {
                currentNumber = Math.random();
                currentNumber = currentNumber * 100;
                currentNumber = Math.round(currentNumber);
                System.out.println(currentNumber);
            }
            System.out.println("One of your numbers have been found");
        }
        System.out.println("All your numbers have been found.");
}
}

