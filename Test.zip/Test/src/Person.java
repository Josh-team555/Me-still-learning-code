class Person {
    private String name;
    private int age;
    Person(String n, int a) {
        name = n;
        age = a;
    }
    static class Codling extends Person {
        Codling(String n, int a, int Team, int codingtime) {
            super(n, a);
            System.out.println("You are on " + Team + " and have coded for " + codingtime + " years");
        }
    }
    static class Buildling extends Person {
        Buildling(String n, int a, int Team, String favoriteTool) {
            super(n, a);
            System.out.println("You are on " + Team + " and your favorite tool is " + favoriteTool);
        }
    }
    void Talk() {
        System.out.println("Hello! I am " + name + " and I am " + age + " years old");
    }
}