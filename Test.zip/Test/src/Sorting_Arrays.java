public class Sorting_Arrays {
    static double array[] = new double[10];
    static boolean sort = false;
    static double dummySpot;
    static int amountSorted = 0;
    public static void main(String[] args) {
        array[0] = 0;
        array[1] = -6;
        array[2] = 4;
        array[3] = 2;
        array[4] = 100;
        array[5] = 42;
        array[6] = 88;
        array[7] = 93;
        array[8] = 2;
        array[9] = 1;
        while(sort == false) {
            for (int i = 0; i < (array.length -1); i ++) {
                if (array[i] < array[(i + 1)]) {
                    dummySpot = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = dummySpot;
                } else {
                    amountSorted = amountSorted + 1;
                    if (amountSorted == 9) {
                        sort = true;
                    }
                }
            }
            amountSorted = 0;
        }
        System.out.println("You are sorted.");
        for (int i = 0; i < array.length; i ++) {
            System.out.println(array[i]);
        }
        System.out.println("Be happy and grateful to this mystical device for it's service to you");
    }
}
