import java.util.Scanner;
public class quadratic_runner {
    static double x1;
    static double x2;
    private static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
        while (true) {
            System.out.println("Enter your a value: ");
            double a = input.nextDouble();
            System.out.println("Enter your b value: ");
            double b = input.nextDouble();
            System.out.println("Enter your c value: ");
            double c = input.nextDouble();
            System.out.println(a + "x * x + " + b + "y + " + c + " = 0");
            System.out.println("Is this your equation?(capital Y if true)");
            if (input.next().equals("Y")) {
                new quadraticFormula(a, b, c);
                if (x1 >= 0 || x1 <= 0 && x2 >= 0 || x2 <= 0) {
                    System.out.println("You're roots are: " + x1 + " and " + x2);
                } else {
                    System.out.println("No solution. :-(");
                }
            } else {
                System.out.println("Try again if it's the wrong equation.");

            }
        }
    }
}